# APBM-007B — Q4 partial, STOP-PRIVACY

Decision needed: Friday/Tony must authorize bounded recovery for `ROLE_OWNER_A_PASSWORD` and `ROLE_OWNER_B_PASSWORD` (recommended: rotate those existing SCRATCH QA passwords and revoke their sessions), or explicitly adjudicate the contained local-artifact risk. Existing retention forbids Cody from changing sign-in fixtures unilaterally. No credential values, raw contexts or credential hashes are in this package.

Read in order:

1. evidence/Q4/01/privacy_stop_2026-11-18.json and privacy_stop_process_exit.json.
2. HANDOFFS/QA_Q4_PRIVACY_RESUME.md for the exact remaining work and counters.
3. QAM_EXECUTION_REPORT.md, latest Q4 update; FINDINGS.md, Q4 proposals (Friday's section2 dispositions are unchanged).
4. evidence/Q4/01/live_campaign.json, browser results and financial proof. FILE_INDEX identifies every member and its source/hash.

Same repaired pair: Portal00a9e0e98aadb2bdba830ebe6d8c06fb6902e37d / OwedBook1fd5a61073e8adaa7997e1ad3c4b1f02d0e7f54d. Q4 is not complete or certified. All7 clock deadline cases and6of7 real deadline cases passed; the final real race was interrupted unpaid. Both genuine crash scenarios, second approved refund closure,50/49 guards, actual68700c renewal and original-record paid re-add passed. New hydration and WebKit failures are retained, not repaired or waived. All unit/type/lint/local SQL/build/bundle checks passed. Support runbook6dry runs passed. Current provider367/400(last20 reserved), no counter reset.

Privacy containment: confirmed Q4 parent0775/file0664 was restricted to0700/0600. A retained Q2 password-bearing file was also contained; prior parent reachability was not retained and is not asserted. Prior unauthorized access is unknown. Synthetic local control verified the runner snapshot opt-out. Old review archives were rescanned in memory for actual QA passwords and raw contexts: none found. QA apps/listener are actually stopped; Director ports stay up. All fixtures retained, protected F001refund0.

Not included: environment/config credentials, private QA cast, Auth state/cookies/tokens, raw error-context files or private logs, builds/dependencies, private mirrors, old ZIPs. Historical Q2 results referenced only with original commits and explicit unchanged-path reasons. The full Portal old-to-repaired diff includes historical QA archives and is referenced by hash; the repair-only and full OwedBook diffs are included. Four reviewed sanitized dashboard screenshots are selected. No retrospective claim of automatic activation is made for owner-poll cases during the intentional listener outage.
