# QAM_RISK_REQUIREMENTS — `APBM-007B-CYBER-PHARMA`

> TEMPLATE SET v0.3 — QA LEAD ACCEPTED WITH EXACT AMENDMENTS (Fable, 2026-10-14); AMENDMENTS ARCHITECT-VERIFIED; INSTALLATION REQUIRES THE APPROVED DOCSET SYNC. Template `QAM/QAM_RISK_REQUIREMENTS.md` v0.3-draft (2026-10-14), from `QAM_PLAYBOOK_v1_0.md` §5, §7 ("QA Lead standing requirements are reusable"), §12 and §16. **Owners: §1 QA Lead (standing, reusable across modules; the QA Lead need not review every engineering packet before work begins); §2 Architect (module-specific risks, clearly attributed); §3 QA Executor (its own reading of both, recorded in Q1; an Executor-owned section inside this file, per `QAM_ENTRY.md` §3).** Nothing here is a test plan; the plan is drafted independently by the Executor from this file, the contract, the source, recon and the Engineer's claims.

## 1. QA Lead standing requirements (reusable; version QAM-SR v1.0; adopted by: QA Lead (Fable), 2026-10-14)

> **STANDING REQUIREMENTS ADOPTION RECORD.**
>
> | Field | Value |
> |---|---|
> | Standing requirements version | **QAM-SR v1.0** |
> | Adopted by | QA Lead (Fable) |
> | Date | 2026-10-14 |
> | Scope | SR-1 through SR-11 adopted, with amendment AM-3 (SR-3 wording) applied |
> | Reuse | Reusable across modules without per-module re-review |
> | Decision source | QA Lead decision ACCEPT WITH EXACT AMENDMENTS for template set v0.2-draft, 2026-10-14 (preserved verbatim in the intake addendum's `QA_LEAD_DECISION_2026-10-14.md`); recorded here by the Engineer seat as instructed, not as its own decision |
>
> The rows below are the adopted QAM-SR v1.0 text. Changes to them require a new QA Lead adoption record with a new version; a module never edits this section (`QAM_ENTRY.md` §3). The Architect's module-specific input (§2) and the Executor's reading (§3) remain separate sections.

| # | Standing requirement | Playbook basis | Applies to |
|---|---|---|---|
| SR-1 | Every AC gets a test or a separately authorized applicability ruling; expected results are independently derived, never copied from engineering claims | §8 | all modules |
| SR-2 | Negative controls and negative paths are planned, not only happy paths | §8, §10 | all |
| SR-3 | Evidence: every PASS/FAIL cites an evidence path with the command, working directory, exit code and unfiltered output; existence checks precede greps/diffs so vacuous passes are impossible | §10 | all |
| SR-4 | Browser coverage is stated as role × route/workflow × data/filter state × viewport × theme, with reductions explained; rendered behavior, effective theme, keyboard/focus, errors, loading/stale/rejection states and access denials are checked; screenshots supplement assertions | §12 | modules with UI |
| SR-5 | Credentials: declared ignored file only; no `NEXT_PUBLIC_*` reuse for QA passwords; file proved ignored AND untracked; schema validated without emitting values; values never in build/server env, commands, logs, exceptions, screenshots, traces, JSON or ZIPs; a service-role key never substitutes for proving a user's login | §12 | modules with auth |
| SR-6 | Privacy scanners validated with synthetic leak fixtures and clean controls; raw authenticated traces treated as sensitive; only approved sanitized evidence retained | §12 | all with browser/API traces |
| SR-7 | Side effects: backend, commerce and agent tests may mutate state or trigger cost; permitted effects and test targets are declared before execution | §12 | BIM / FEAT / FIX touching backends |
| SR-8 | Instruments: a helper that cannot fail is not an instrument; attack at least one deliberately; never weaken assertions, add hidden retries, skip tests or change product code to obtain green | §10 | all |
| SR-9 | Result labels are observations (PASS / FAIL / BLOCKED / NOT RUN / ADJUDICATE); an unresolved discrepancy never becomes PASS by relabeling | §11 | all |
| SR-10 | Human checks are declared beforehand, grouped near the end where independent, and counted; never fake an unattended run | §10 | all |
| SR-11 | Regression scope: required regression suite named by the plan; carried-forward evidence shows its applicability and original SHA/attempt | §8, §11 | all |

## 2. Architect module-specific risk input — JARVIS, 16 November 2026

QA Lead's 007B requirements remain unchanged in ../GOVERNING/QA_LEAD_REQUIREMENTS_APBM007B_2026-11-16.md. They are standing inputs, not this package's review verdict or a Q1 plan.

| Risk | Contract/source | Required evidence shape |
|---|---|---|
| Failed Add Store starts grace; standalone invoice unmapped | BILLING and webhook | operation-aware event race, no renewal state/notice |
| APA discount recovered; quote equals wrong price | AC003, CP1/CP2 | earned discount retained, mid-period fraction, real invoice |
| Lost response/expired consent/double activation | AC004–008 | real SQL concurrency, invoice history, late-payment, void/paid race |
| Pending store exposes data | no ownership row before activation | app/data/definer negatives |
| New owner sees history or two active NPIs | canonical identity/ownership | buyer/seller/staff matrix and concurrent transfer |
| Admin gap/replay/wrong user/cross-account grants | invitations | explicit POST, incumbent lock, data-layer revocation |
| Test time leaks into ordinary access | clock contract | disabled-context non-null fixture, DEV/staging/user negatives |
| Mail duplicate/recovery race/unmeasured dispatch | notices | runtime guard first, attempts and real inbox, retention horizon |
| Operator actor falsely called personally authenticated | recovery audit | separate credential/declared actor, known staging limitation |
| New SQL permissions or applied data damaged | migrations | fresh/upgrade/forward-resume and two accounts every object |
| UI success mocked away | engineering/prod browser | final rendered destination AND stored state; touched U1/U2/U3 |

APBM adaptation: complete data/API/permission contracts, phase baseline/carry-forward, effect limits, independent candidate pair, synthetic fixtures and staging/Gate D distinction. Roles OWNER_A/B, admin, member, foreign, recipient, signed-out. Affected Add Store/staff/invite/removal/billing/archive/recovery flows cover successful/loading/error/stale/decline/auth states, 375/1440 light/dark and keyboard. Q1 independently derives full matrix and justifies reductions; no pre-approved plan.

QA effects: Q1 local source/build/instrument lanes only plus any separately stated setup grant. Q2/Q4 live allowance is Friday-approved candidate/plan plus Tony's release; engineering ceilings never transfer. Human inbox/payment confirmations grouped near end where independent; all touches counted. One measured QA capsule, final repaired candidate for one-time new identities/payment journeys, no human to run repeatable tests.

## 3. Executor's reading (Q1) — contradictions and open risk questions (QA Executor-owned section)

Cody, 2026-11-17: SR1–11 adopted as inputs; contract hash mismatch is STOP-CONTRACT for execution binding. Automatic webhooks and actual inbox observation remain independent gaps; no E2 effect authority transfers. See recon consolidated decisions and draft plan.

*TEMPLATE SET v0.3 — QA LEAD ACCEPTED WITH EXACT AMENDMENTS (Fable, 2026-10-14); AMENDMENTS ARCHITECT-VERIFIED; INSTALLATION REQUIRES THE APPROVED DOCSET SYNC.*
