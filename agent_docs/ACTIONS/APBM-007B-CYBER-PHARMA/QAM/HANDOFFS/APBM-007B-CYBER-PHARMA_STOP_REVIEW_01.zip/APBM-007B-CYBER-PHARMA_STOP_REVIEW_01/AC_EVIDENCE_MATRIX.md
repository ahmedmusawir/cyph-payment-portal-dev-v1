# Acceptance/evidence matrix — Q2/01 partial

No certification. NOT RUN means full criterion unfinished even where partial checks passed.

| AC | Test | Full-criterion status | Evidence / qualification |
|---|---|---|---|
| AC-001 | T-001 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-002 | T-002 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-003 | T-003 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-004 | T-004 | FAIL | F-Q2-001; late_outage_refund/timeline_facts.json and diagnostic.json; other lifecycle checks passed separately |
| AC-005 | T-005 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-006 | T-006 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-007 | T-007 | FAIL | F-Q2-001; late_outage_refund/timeline_facts.json and diagnostic.json; other lifecycle checks passed separately |
| AC-008 | T-008 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-009 | T-009 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-010 | T-010 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-011 | T-011 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-012 | T-012 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-013 | T-013 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-014 | T-014 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-015 | T-015 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-016 | T-016 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-017 | T-017 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-018 | T-018 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-019 | T-019 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-020 | T-020 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-021 | T-021 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-022 | T-022 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-023 | T-023 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-024 | T-024 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-025 | T-025 | FAIL | F-Q2-001; late_outage_refund/timeline_facts.json and diagnostic.json; other lifecycle checks passed separately |
| AC-026 | T-026 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-027 | T-027 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-028 | T-028 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-029 | T-029 | NOT RUN | QAM_EXECUTION_REPORT.md; evidence/Q2/01/ (partial evidence by layer) |
| AC-030 | T-030 | FAIL | F-Q2-002; browser/ob_staff.txt; Portal9/9 and OB4 passed, remaining journey matrix incomplete |
| AC-031 | T-031 | PASS | board/client_bundle_scan.json; preflight/bundle_controls.json; narrowly approved library exception |
| GD-001 | D-01 | NOT RUN | Separate revision-bound staging gate; local CLI not native HTTPS retry proof |
