# Friday — Q2/01 partial return at authority limit

Read QAM_EXECUTION_REPORT.md → FINDINGS.md section1 → late_outage_refund/timeline_facts.json and diagnostic.json → effects/counters.json → AC_EVIDENCE_MATRIX.md. This is NOT Q2 complete or certification.

F-Q2-001: actual provider payment11:50:29Z exceeded consent deadline11:49:29Z on verified SCRATCH/provider clock; store nevertheless activated. Proposed high acceptance failure, AC004/007/025. No product repair and no refund of this activated store performed. Please adjudicate and route bounded Engineering repair if warranted, preserving timely-paid/delayed-delivery behavior. F-Q2-002 retains WebKit staff timeout; F-Q2-003 discloses QA reservation/instrument limitations. No hidden retest or blanket PASS.

60 normal provider mutation reservations consumed;20 exclusively reserved for cleanup of80 total remain. STOP-AUTHORITY prevents further normal effectful tests. Recommendation to Tony: cap120 (100 active+20 cleanup), sign-ins64, with existing counters preserved and next-case dry-run/instrument audit before continuation. New-identity counter9 includes rejected existing-user attempt;8 unique actual identities. No cap changed here.

Unaffected independent checks continued and are summarized by layer. Incomplete criteria stay NOT RUN; Gate D remains separate. Grouped manual inbox observations still pending (invitation emails + two billing notices); no actual receipt invented. QA runtime/fixtures retained for adjudication/resume, no closeout or retention acceptance claimed; Director apps untouched and Director listener should remain off until owned listener stops.

Not included: private files, passwords, addresses/inbox links, JWT/cookie state, raw private traces/screenshots, builds/dependencies, old ZIPs, unreviewed raw full records diff. Contracts/governing files and engineering claims referenced by exact current source hashes in SOURCE_REFERENCES.json. Sanitized textual exports explicitly identify their original source; unfiltered originals remain at their governed/private paths. Original Friday attachment is a supplied reference, not independently received bytes. ZIP state is pre-export; hash only external.
