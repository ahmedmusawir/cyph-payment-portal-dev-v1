#!/usr/bin/env node
// APBM-007B — controlled-inbox adapter for O-2 and invitation proofs (actual inbox observation). cwd: Portal root.
//
//   node scripts/apbm007b/inbox.mjs --help
//   node scripts/apbm007b/inbox.mjs --check                                     # validate the private files (shape only), no network
//   node scripts/apbm007b/inbox.mjs --wait --role <ROLE> --subject <text> --since <ISO> [--timeout 300] [--link-out /tmp/<f>]
//
// Private inputs (never in a repo, never printed):
//   ~/.apbm007b/engineering_cast.json  mode 0600: { "<ROLE>": { "email": "...", "password": "..." }, ... }  roles
//                                       ENGINEERING_OWNER_A, ENGINEERING_OWNER_B, ENGINEERING_ADMIN, ENGINEERING_MEMBER, ENGINEERING_INVITEE
//   ~/.apbm007b/inbox_access.json      mode 0600: { "adapter": "imap", "host": "...", "port": 993, "user": "...", "password": "...",
//                                       "mailbox": "INBOX" }  — one IMAP account that RECEIVES every cast address (aliases or
//                                       plus-addresses are fine); messages are matched by the To header = the role's address.
// --wait polls IMAP (TLS) read-only (EXAMINE, never deletes or flags) for a message to that role's address, received at or
// after --since, whose subject contains --subject. It prints only: found, subject, received time, and whether a sign-in
// link was present. With --link-out, the first https link to the app's /api/auth/confirm is written to that /tmp file at
// mode 0600 for the browser step (a one-time capability; never printed or packaged). Uses Python's standard imaplib.
import { spawnSync } from 'node:child_process';
import { readFileSync, statSync, existsSync } from 'node:fs';
import { homedir } from 'node:os';

const args = process.argv.slice(2);
if (!args.length || args.includes('--help')) { console.log(readFileSync(new URL(import.meta.url)).toString().split('\n').filter((l) => l.startsWith('//')).map((l) => l.slice(3)).join('\n')); process.exit(0); }
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : undefined; };
const CAST = `${homedir()}/.apbm007b/engineering_cast.json`, ACCESS = `${homedir()}/.apbm007b/inbox_access.json`;
const ROLES = ['ENGINEERING_OWNER_A', 'ENGINEERING_OWNER_B', 'ENGINEERING_ADMIN', 'ENGINEERING_MEMBER', 'ENGINEERING_INVITEE'];
function privateJson(p) {
  if (!existsSync(p)) return { error: 'missing' };
  if ((statSync(p).mode & 0o077) !== 0) return { error: 'mode_not_0600' };
  try { return { value: JSON.parse(readFileSync(p, 'utf8')) }; } catch { return { error: 'invalid_json' }; }
}
const cast = privateJson(CAST), access = privateJson(ACCESS);
if (args.includes('--check')) {
  const c = cast.value ?? {}, a = access.value ?? {};
  console.log(JSON.stringify({ engineering_cast: cast.error ?? 'ok', roles_present: ROLES.filter((r) => /@/.test(c[r]?.email ?? '')), roles_missing: ROLES.filter((r) => !/@/.test(c[r]?.email ?? '')),
    inbox_access: access.error ?? 'ok', inbox_shape_ok: a.adapter === 'imap' && !!a.host && !!a.user && !!a.password }, null, 1));
  process.exit(cast.error || access.error ? 1 : 0);
}
if (!args.includes('--wait')) { console.error('FAIL-CLOSED: --check or --wait'); process.exit(2); }
if (cast.error || access.error) { console.error(`FAIL-CLOSED: private inputs ${cast.error ?? ''} ${access.error ?? ''}`); process.exit(2); }
const role = opt('--role'), subject = opt('--subject'), since = opt('--since'), linkOut = opt('--link-out');
const to = cast.value[role]?.email;
if (!to || !subject || !since || Number.isNaN(Date.parse(since))) { console.error('FAIL-CLOSED: --role, --subject, --since required'); process.exit(2); }
if (linkOut && !/^\/tmp\/[A-Za-z0-9._-]+$/.test(linkOut)) { console.error('FAIL-CLOSED: --link-out must be /tmp/<file>'); process.exit(2); }
const PY = `
import imaplib,email,json,sys,time,re,os
from email.utils import parsedate_to_datetime, getaddresses
from datetime import datetime,timezone
a=json.load(open(sys.argv[1])); to=sys.argv[2].lower(); subj=sys.argv[3]; since=datetime.fromisoformat(sys.argv[4].replace('Z','+00:00')); timeout=int(sys.argv[5]); out=sys.argv[6]
end=time.time()+timeout; found=None
while time.time()<end and not found:
  m=imaplib.IMAP4_SSL(a['host'],int(a.get('port',993))); m.login(a['user'],a['password']); m.select(a.get('mailbox','INBOX'),readonly=True)
  typ,data=m.search(None,'SINCE',since.strftime('%d-%b-%Y'))
  for num in reversed((data[0] or b'').split()[-50:]):
    typ,msg=m.fetch(num,'(BODY.PEEK[])'); e=email.message_from_bytes(msg[0][1])
    tos=[x[1].lower() for x in getaddresses(e.get_all('to',[])+e.get_all('delivered-to',[]))]
    try: when=parsedate_to_datetime(e['date'])
    except Exception: continue
    if to in tos and subj.lower() in (e['subject'] or '').lower() and when>=since:
      body=''
      for part in e.walk():
        if part.get_content_type() in ('text/plain','text/html'):
          try: body+=part.get_payload(decode=True).decode(part.get_content_charset() or 'utf-8','replace')
          except Exception: pass
      link=re.search(r'https?://[^\\s"<>]+/api/auth/confirm[^\\s"<>]*',body)
      if link and out:
        fd=os.open(out,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600); os.write(fd,link.group(0).replace('&amp;','&').encode()); os.close(fd)
      found={'found':True,'subject':e['subject'],'received':when.isoformat(),'sign_in_link_present':bool(link),'link_written':bool(link and out)}
      break
  m.logout()
  if not found: time.sleep(10)
print(json.dumps(found or {'found':False}))
`;
const r = spawnSync('python3', ['-I', '-c', PY, ACCESS, to, subject, since, String(Number(opt('--timeout') ?? 300)), linkOut ?? ''], { encoding: 'utf8', timeout: (Number(opt('--timeout') ?? 300) + 60) * 1000 });
process.stdout.write(r.stdout); if (r.status !== 0) console.error(`[inbox] adapter exit ${r.status}`);
process.exitCode = r.status ?? 1;
