# RWO-01 changed files, grouped by item

Working-tree changes only. Nothing is staged or committed. Full diffs: `diff/owedbook_full.diff` and `diff/portal_full.diff`.

## OwedBook (`cyph-v1-dev`), 20 paths

| Item | Product file | Test |
|---|---|---|
| R-01 | `src/app/(public)/HomePageContent.tsx` | `src/__tests__/abm007/home-cta.test.tsx` (new) |
| R-02 | `src/components/help/HelpPage.tsx` | `src/__tests__/abm007/help-page.test.tsx` |
| R-03 | `src/components/auth/LoginForm.tsx` | `src/__tests__/auth/LoginForm.hydration.test.tsx` |
| R-04 | `src/components/ui/input.tsx` | `src/__tests__/member/ProfileForm.test.tsx` |
| R-05 | `src/app/profile/ProfileForm.tsx` | `src/__tests__/member/ProfileForm.test.tsx` (same file) |
| R-06 (a) | `src/components/ui/password-input.tsx` | `src/__tests__/auth/PasswordToggle.test.tsx` |
| R-06 (b) | `src/components/owedbook/OwedBookScreen.tsx` | `src/__tests__/owedbook/OwedBookScreen.test.tsx` |
| R-06 (c) | `src/components/global/Navbar.tsx`, `src/components/global/UserMenu.tsx` | `src/__tests__/global/Navbar.mobile.test.tsx`, `src/__tests__/global/UserMenu.test.tsx` |
| R-07 | `src/components/global/Navbar.tsx` (same file as R-06 (c)), `src/components/admin-portal/ScreenHeader.tsx` | `src/__tests__/global/Navbar.mobile.test.tsx` (same file). `ScreenHeader` has no existing test, so none was added |
| Records | `CHANGELOG.md`, `agent_docs/SESSIONS/session_2026-11-26.md` (new) | — |

Product files: 10. Test files: 8 (1 new, 7 extended). Record files: 2.

## Account & Billing (`cyph-payment-portal-dev-v1`)

### RWO-01 items, 8 paths

| Item | Product file | Test |
|---|---|---|
| R-04 (same fade, same fix) | `src/components/ui/input.tsx` | No existing test covers this component; none added |
| R-08 | `src/components/portal/PublicShell.tsx`, `src/components/portal/Footer.tsx` | `src/__tests__/abm007/public-shell-fit.test.tsx` (new) |
| R-09 (a) | `src/components/portal/FormField.tsx` | `src/__tests__/password-field.test.tsx` |
| R-09 (b) | `src/components/portal/account/StoreRemovalControl.tsx` | `src/__tests__/manual-qa-portal-ui.test.tsx` |
| R-09 (c) | none (identified, not changed) | — |

Product files: 5. Test files: 3 (1 new, 2 extended).

### RWO-01 records

| File | Change |
|---|---|
| `agent_docs/ACTIONS/ABM007_FINAL/ABM_RULINGS.md` | Rows AM-18 to AM-21 appended after AM-17, byte-identical to the release document |
| `agent_docs/ACTIONS/ABM007_FINAL/EVIDENCE/E2/CHANGED_LABELS.md` | RWO-01 section appended |
| `agent_docs/ACTIONS/ABM007_FINAL/EVIDENCE/RWO01/` (new folder) | This report and its lists, `tools/measure.mjs`, `measure/` data and masked screenshots, `logs/`, `diff/`, `binding/` |
| `CHANGELOG.md`, `session_2026-11-26.md` | Appended entries |
| `agent_docs/RESPONSES/response_2026-11-26_*_rwo01-engineering-return.md`, the ZIP copy and its `.sha256` in `EVIDENCE/RWO01/` | Written after the ZIP was built, so they are not inside it |

### Not RWO-01: record changes made earlier today at the Director's request

| File | Change |
|---|---|
| `session_2026-11-26.md` (new) | Today's session log, started before RWO-01 arrived |
| `RECOVERY.md` | One block added at the top; nothing else changed |
| `agent_docs/ACTIONS/ABM007_FINAL/ABM_STATE.md` | Index refreshed to the QA state as it stood this morning |
| `CHANGELOG.md` | Two entries for the above |

### Not touched

`agent_docs/ACTIONS/ABM007_FINAL/QAM/` holds the QA Executor's uncommitted records. I changed nothing there, and both diffs leave it out.
