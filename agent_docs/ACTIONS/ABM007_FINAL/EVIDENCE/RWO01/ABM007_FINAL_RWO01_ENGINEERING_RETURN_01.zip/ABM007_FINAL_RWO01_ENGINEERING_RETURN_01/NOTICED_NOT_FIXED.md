# Noticed during RWO-01 and not fixed

Reported under the work order's rule: anything outside R-01 to R-09 is reported, not fixed.

| # | What | Where | Why it may matter |
|---|---|---|---|
| 1 | "Refresh" on the Account & Billing dashboard and billing pages is drawn as a 12px link | `src/components/portal/account/DashboardView.tsx` line 221 | R-09 (c). Needs the QA Lead's ruling: make it a button, or keep it a link and decide its text size |
| 2 | The **signed-in** Account & Billing footer breaks its links across lines at 768 wide | `src/components/portal/Footer.tsx` (default tone); measured on `/dashboard` and `/billing` | Same defect as R-08, but R-08 names the signed-out pages only. I changed the signed-out footer and left this one |
| 3 | "Start free trial" remains in the opening page's header and mobile menu | `UserMenu.tsx`, `MobileNav.tsx` | R-01 asks for a list, not a change. See `FREE_TRIAL_LIST.md` |
| 4 | Other components still fade when disabled (50% opacity) | OwedBook `src/components/ui/textarea.tsx`, `select.tsx`, `tabs.tsx`, `command.tsx`; Account & Billing `src/components/ui/textarea.tsx` | R-04 names the input field. I found no screen that shows a disabled multi-line field today, but these would fail the same contrast rule if one did |
| 5 | The eye button inside a **disabled** password field fades to 50% | OwedBook `password-input.tsx`; Account & Billing `FormField.tsx` | It is an icon, not text. Not seen disabled on any page today |
| 6 | At 320 wide the OwedBook header wordmark shortens to "Pharmacy …" | `src/components/global/Navbar.tsx` | A result of the R-07 fix. Account & Billing already does this at 320. From 375 up the wordmark is whole |
| 7 | Below 1024 wide, "Go to the Top" is at the bottom of a contents menu that sits above the text | Help page | R-02 asked for a report here and no new design. A reader at the bottom of Help cannot see the link at phone and tablet widths |
| 8 | On a short window (I estimate under about 730px tall, at 1024 wide or more; not measured), the Help contents menu is taller than the window, so its last item, "Go to the Top", can sit below the fold | Help page | The menu stays fixed while reading and does not scroll on its own. This was already true of the last section links |
| 9 | The member-list avatar in the OwedBook admin pages is 40px | `src/components/admin-portal/MemberRow.tsx` | It is a picture, not a button, so R-06 (c) does not cover it |
| 10 | The Login button's duplicate-submit guard is the disabled button only | `src/components/auth/LoginForm.tsx` | Unchanged by R-03. A real second press cannot get through; I mention it because a test that fires the form event directly can |
| 11 | `ABM_STATE.md` now shows `Q2 COMPLETE — AWAITING ADJUDICATION` | module folder | It was refreshed this morning, before the adjudication arrived. I did not update it again for RWO-01, because the work order lists the records to touch |
| 12 | Firefox was not measured | — | The measuring tool uses Chrome and WebKit. The retest covers three engines |
| 13 | The OwedBook Store selector uses the browser's own disabled look while stores load or when there are none | `src/components/owedbook/StoreSelector.tsx` | It is a built-in dropdown, not the input field R-04 names. Its disabled contrast was not measured |
