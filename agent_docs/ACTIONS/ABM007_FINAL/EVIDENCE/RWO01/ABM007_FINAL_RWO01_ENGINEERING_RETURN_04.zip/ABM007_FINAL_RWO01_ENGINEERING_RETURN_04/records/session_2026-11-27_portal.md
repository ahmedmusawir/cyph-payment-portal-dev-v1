# Session Log: 2026-11-27

## Project Context
- **Project:** cyph-payment-portal-dev-v1 (Account & Billing), with companion OwedBook `cyph-v1-dev`
- **Tool:** Claude Code
- **Goal:** Not set yet. Engineering returned RWO-01 and add-on A1 on 26 Nov and is waiting. QA (Cody) is running Q4 and has both builds serving for the Director's walkthrough.

## Starting State
- **Branch:** `qa/abm007-final` in both repositories.
  - Portal HEAD `fc1fa6c2a90ebf59987287ad765e2e65cf635549` (unchanged since 24 Nov)
  - OwedBook HEAD `2e91e90905b2d9907577a64985e643f7827019ac` (unchanged since 24 Nov)
- **Working tree at start (08:24):** the RWO-01 and add-on A1 repairs are still uncommitted in both repositories. Nothing staged, no stash.
  - Portal: 7 product and test files modified, 1 new test, the records (`ABM_RULINGS.md`, `ABM_STATE.md`, `CHANGED_LABELS.md`, `RECOVERY.md`, `CHANGELOG.md`), `EVIDENCE/RWO01/`, two response files, `session_2026-11-26.md`. QA's own uncommitted records under `QAM/` are Cody's lane.
  - OwedBook: 22 paths, as in `EVIDENCE/RWO01/STAGING_LIST_owedbook.txt`.
- **Last Working Feature:** RWO-01 items R-01 to R-09 (a)(b) and add-on A1-1 to A1-4, checked on 26 Nov: OwedBook 408 of 408, Portal 588 of 588, typecheck clean, lint 0 errors, both production builds succeeded.
- **Engineering status line (26 Nov):** `RWO-01 ADD-ON A1 COMPLETE — AWAITING DIRECTOR COMMIT`.
- **QA state, read-only from `QAM/QAM_STATE.md` (written 27 Nov 08:15):**
  - Q4 progress export 01 was made on 26 Nov 15:35.
  - 27 Nov: "Sheet 04 readiness rebuild". Both local listeners were restarted and are serving for the Director's walkthrough.
  - The "Current state" table in that file still shows `Q2 COMPLETE — AWAITING ADJUDICATION`; the dated entries below it are newer.
- **Local servers at start:** ports 3100 and 3101 are listening since 08:15 today, from `/tmp/abm007-final-cody-q4/ob` and `/pp`. They are QA's, not Engineering's. Not touched.
- **Known Issues:**
  - Both return ZIPs are no longer in `~/Downloads`. The copies in `EVIDENCE/RWO01/` are intact and their SHA-256 values match (`e64985c0…` return 01, `553c89e5…` return 02).
  - `ABM_STATE.md` and the top block of `RECOVERY.md` date from 26 Nov 12:4x and trail RWO-01, the add-on and Q4. Not updated: `RECOVERY.md` is protected until closeout (AM-06), and no request covers either file today.
  - Row AM-22 in `ABM_RULINGS.md` was typed from the QA Lead's message; a compare against the QA Lead's copy is still open.
  - Keyboard focus outline of the end-of-text "Go to the Top" link was not captured on 26 Nov.
  - O-1 (WebKit interruption in the redirect reproduction) stays with QA.
  - External settings (Supabase template, Stripe branding) prepared, not applied.
- **Limits carried over:** sign-in sessions 12 of 20 used under RWO-01. No Git action by the Engineer. No QAM file touched. SCRATCH only.

## Since the last session file (26 Nov, last entry 13:42)
- No engineering work after the add-on A1 return.
- QA continued with Q4 (their records, not Engineering's).

## Session Progress

### 08:24 — COMPLETE (session start)
**Task:** New session file, at the Director's request.
**Files changed:** `session_2026-11-27.md` (new), `CHANGELOG.md` (one entry).
**Tests:** none run; no product file touched.
**Notes:**
- Read-only checks only: clock, both HEADs and working trees, `RECOVERY.md`, yesterday's session file, `QAM/QAM_STATE.md`, listeners, ZIP hashes.
- `RECOVERY.md` not changed (not requested today; protected until closeout).
- No Git action. No QAM file touched. QA's servers left running.

### 10:38 — STOPPED AT ENTRY (RWO-01 add-on A2)
**Task:** QA Lead's add-on A2 (A2-1 Help "Go to the Top" at the end of each article; A2-2 focus outlines, verify first; row AM-23; labels; staging lists).
**Stop:** the work order says to read `QA_LEAD_ADJUDICATION_ABM007_FINAL_Q4_2026-11-27.md` in the VM Downloads folder first, and to stop if it cannot be opened. It is not there. `~/Downloads` holds only `ABM007_FINAL_Q4_REVIEW_01_2026-11-27_102756_BDT.zip` and `_ARCHIVE/`; a search of the home folder by name found no Q4 adjudication for this module. The Director pasted the document's text into the conversation, but there is no file to open.
**Entry checks (passed):** both repositories on `qa/abm007-final` at `2e91e90…` and `fc1fa6c…`; nothing staged; product files changed are only the RWO-01 and A1 set (OwedBook 20 modified and 2 new; Portal 7 modified and 1 new test).
**Files changed:** this entry only. No product file, no record, no QAM file, no sign-in, no Git action.

### 11:05 — APPROVED → IN PROGRESS (RWO-01 add-on A2)
**Task:** QA Lead's add-on A2, released by the Director on 27 Nov, on top of the uncommitted RWO-01 and A1 working trees. A2-1: "Go to the Top" at the end of each of the 13 Help articles; removed from the contents menu and from the end of the Help text. A2-2: focus outlines, verify first (Help contents menu links at 1440 x 900 and 1024 x 600; Add control on OwedBook billing at 375; password field and its show-or-hide button on Profile at 375). Records: `ABM_RULINGS.md` row AM-23, `CHANGED_LABELS.md`, Help tests, regenerated staging lists.
**Governing document:** `QA_LEAD_ADJUDICATION_ABM007_FINAL_Q4_2026-11-27.md` was still not in `~/Downloads` at 11:00. After my stop the Director pasted its full text into the conversation a second time; I work from that pasted text (section 6). No file was opened, so no file hash is recorded.
**Entry check:** both repositories on `qa/abm007-final` at `2e91e90…` and `fc1fa6c…`; nothing staged. Product and test files are byte-identical to the A1-tested copies (`binding_a1`); only `CHANGELOG.md` (both) and the Portal session logs differ. Ports 3100 and 3101 free (QA's listeners are gone).
**Limits:** at most 8 sign-in sessions; no Account & Billing dashboard or billing page load; SCRATCH only.
**Approved at:** 11:05 (the work order itself).

### 11:17 — COMPLETE (RWO-01 ADD-ON A2 COMPLETE — AWAITING QA CONFIRMATION)
**Task:** add-on A2-1 and A2-2.
**Files changed:** OwedBook `src/components/help/HelpPage.tsx` and `src/__tests__/abm007/help-page.test.tsx`; OwedBook records `CHANGELOG.md`, `agent_docs/SESSIONS/session_2026-11-27.md` (new). Portal records: `ABM_RULINGS.md` row AM-23, `CHANGED_LABELS.md`, `CHANGELOG.md`, `EVIDENCE/RWO01/` (report 03, `tools/measure_a2.mjs`, measurements, `logs_a2/`, `binding_a2/`, regenerated diffs, lists, staging lists, `COMMIT_MESSAGES.md`), a response file. No Portal product or test file changed.
**Tests:** OwedBook 408 of 408, Portal 588 of 588; typecheck clean; lint 0 errors (38 and 27 warnings, unchanged); both production builds succeeded. On hash-bound copies (`binding_a2/`).
**Notes:**
- A2-1: 13 "Go to the Top" links, one at the end of each article, inside it; none in the contents menu, none after the last article. Contrast 4.53 to 1 (dark green on white) at 375 and 1440; before, the end-of-text link was 4.04 to 1 on the light blue page. 44px target; returns to scroll position 0 with the header in view by mouse and keyboard; outline whole on four sides.
- A2-2, verify first: one cut found. At 1024 x 600, contents menu link 12 lost the bottom edge of its outline (4px) under the scrolling menu box. Layout fix: `lg:scroll-py-2` on the menu. After: 13 of 13 whole at 1024 x 600 and 1440 x 900. The Add control, the password field and its show-or-hide button were whole before and are unchanged.
- Tool note: the first "before" run had a tool fault (it scrolled the page and could not read ring-style focus); kept as `measure_a2_before_run1.json`, corrected and rerun.
- Sign-in sessions: 5 of 8 (2 + 1 + 2), all Owner A by password on OwedBook, SCRATCH verified first. No Account & Billing page loaded (counted: 0).
- Servers on 3100 and 3101 stopped. Nothing staged or committed; both HEADs unchanged. No QAM file touched.
- Return package: `~/Downloads/ABM007_FINAL_RWO01_ENGINEERING_RETURN_03.zip`; identity in the response file.

### 12:05 — APPROVED → IN PROGRESS (RWO-01 add-on A3)
**Task:** QA Lead's add-on A3, released by the Director on 27 Nov: in Firefox, at desktop sizes, keyboard Enter on the "Go to the Top" link at the end of Help article 1 does not leave the page at the top. Reproduce in Firefox first, find the cause, then fix only that. Expected files: OwedBook `HelpPage.tsx` and its test. Records: an A3 note in the evidence folder, changelog, regenerated staging lists. No new ruling row.
**Entry check (12:01):** both repositories on `qa/abm007-final` at `2e91e90…` and `fc1fa6c…`; nothing staged. Product and test files byte-identical to the A2-tested copies (`binding_a2`); only `CHANGELOG.md` (both) and this session log differ. Firefox is installed for the test tool (`firefox-1511`).
**Ports:** 3100 and 3101 are in use by the QA Executor's listeners (`/tmp/abm007-final-cody-q4-a2/`, started 11:35). Not mine; not touched. While they run I cannot serve my own build. I start with a reproduction that needs no server and no sign-in: the Help page's own HTML and built CSS opened as a file in Firefox.
**Limits:** at most 6 sign-in sessions; no Account & Billing page; SCRATCH only.
**Approved at:** 12:05 (the work order itself).

### 12:07 — BLOCKED, AWAITING DIRECTOR (RWO-01 add-on A3)
**Done so far (no product file changed, no sign-in, no server started):**
- Firefox 148.0.2 runs here through the test tool.
- A static copy of the Help page (its own HTML from the A2 copy and the built CSS, opened as a file) does NOT reproduce the defect: in Firefox, Enter and mouse click on the article 1, 7 and 13 links leave the page at 0 at 0, 100, 300, 800 and 2,000 ms, at 1024 x 600, 1440 x 900 and 375 wide. So the cause is not in the link's HTML or the CSS; it is in what the running app adds (its scripts or its real header).
- Reading the OwedBook client code found no handler for hash changes or scrolling. Not conclusive.
**Blocker:** reproducing in the running app needs my SCRATCH build on ports 3100 and 3101 (the only pair the ruled tools and the apps' identity table allow). Both ports are held by the QA Executor's listeners (`/tmp/abm007-final-cody-q4-a2/`, since 11:35), which I may not stop. The work order says not to fix blind, so I have not changed anything.
**Scratch note:** a temporary test file `src/__tests__/zz_tmp_dump.test.tsx` is left in the scratchpad copy `rwo01/a2/ob` (not in the repository); a removal was refused by the harness safety check. The A3 build will use a fresh copy.

### 13:18 — COMPLETE (RWO-01 ADD-ON A3 COMPLETE — AWAITING QA CONFIRMATION)
**Task:** add-on A3, the Firefox "Go to the Top" defect.
**Unblocked:** asked the Director about the busy ports; the Director had the QA Executor's servers stopped. Ports checked free at 12:18 before I started mine.
**Cause:** `#top` named no element, so the browser scrolled up but left keyboard focus on the link. Firefox then moved the page back to where it was. Reproduced with QA's numbers (306 at 1024 x 600, 131 at 1440 x 900) when the link is focused by Tab and a script scrolls it into place; reproduced on a file copy with no scripts, so not the app's scripts. Not timing: 4 of 4 fail or 4 of 4 pass per case. Not established: Firefox's internal rule, and why only article 1. Not shown with a reader's own actions.
**Files changed:** OwedBook `src/components/help/HelpPage.tsx` (the "Help" heading is the real, focusable `#top` target with a one-window scroll margin; no script) and `src/__tests__/abm007/help-page.test.tsx` (one test). OwedBook records `CHANGELOG.md`, `agent_docs/SESSIONS/session_2026-11-27.md`. Portal records: `CHANGELOG.md`, `EVIDENCE/RWO01/` (A3 report, tools, measurements, `logs_a3/`, `binding_a3/`, regenerated diffs, lists, staging lists, `COMMIT_MESSAGES.md`), a response file. No Portal product or test file, no ruling row, no label change.
**Tests:** OwedBook 409 of 409, Portal 588 of 588; typecheck clean; lint 0 errors (38 and 27 warnings, unchanged); both production builds succeeded. On hash-bound copies (`binding_a3/`).
**Notes:**
- Grid (articles 1, 7, 13; mouse and keyboard; three sizes; 45 cases per engine): Firefox 43 of 45 before, 45 of 45 after; Chrome and WebKit 45 of 45 before and after. Firefox repeats: 40 of 56 before, 56 of 56 after. All 13 links in Firefox after: 78 of 78.
- All 13 links in Chrome and WebKit: NOT measured. My three-engine step failed on a fault in its own heading check and lost its results; I had closed the driver in the same command. One session was left; used for Firefox.
- Focus after activation: the "Help" heading, in view, in all three engines. It shows the standard white focus outline after keyboard activation (WebKit also after a click). Left visible; reported for the Director's look.
- A2 design re-measured on the A3 build in Chrome and WebKit: unchanged.
- Sign-in sessions: 6 of 6 (3 kept open across the build swap, 2 for the A2 re-measure, 1 for the Firefox rerun). All Owner A by password on OwedBook, SCRATCH verified. No Account & Billing page loaded (requests counted: 0). No session state written anywhere.
- Servers on 3100 and 3101 stopped. Nothing staged or committed; both HEADs unchanged. No QAM file touched.
- Return package: `~/Downloads/ABM007_FINAL_RWO01_ENGINEERING_RETURN_04.zip`; identity in the response file.

## Lessons Learned
- A stop named in a work order is a stop even when the same text is in the conversation: say so, and let the Director decide how to supply it.
- Do not chain "close the tool" after "read the results" in one command: a failed step then costs the sessions. Read first, close after.
- A step file should save each result as it goes and guard its last lines, so a late fault cannot lose earlier work.
- Check the measuring tool on the unchanged build first. The first focus run blamed the window edge for two outlines and missed ring-style focus.

## End of Session State
- **Working:** RWO-01 with add-ons A1, A2 and A3 in both working trees; all checks green on copies.
- **Broken:** nothing known.
- **Next Steps:** QA Executor confirms A3 on fresh manifests (all 13 links in Chrome and WebKit are not yet measured); the Director looks at Help and commits; QA Lead certifies Gate Q.

## Files Changed This Session
- `session_2026-11-27.md` — new
- `CHANGELOG.md` — two entries
- `agent_docs/ACTIONS/ABM007_FINAL/ABM_RULINGS.md` — row AM-23
- `agent_docs/ACTIONS/ABM007_FINAL/EVIDENCE/E2/CHANGED_LABELS.md` — add-on A2 block
- `agent_docs/ACTIONS/ABM007_FINAL/EVIDENCE/RWO01/` — add-on A2 report, tool, measurements, logs, diffs, lists
- `agent_docs/RESPONSES/response_2026-11-27_*_rwo01-a2-engineering-return.md` — new
- OwedBook: `src/components/help/HelpPage.tsx`, `src/__tests__/abm007/help-page.test.tsx`, `CHANGELOG.md`, `agent_docs/SESSIONS/session_2026-11-27.md`
