# Proposed commit messages for RWO-01 with add-on A1 (prepared by Engineering, not executed)

Git authority is the Director's. Nothing is staged. Stage each repository from its list in this folder with `git add --pathspec-from-file=<list>`, then check `git diff --cached --name-status`.

## OwedBook (`STAGING_LIST_owedbook.txt`)

```
git commit -m "fix(abm007-final): RWO-01 repairs R-01 to R-07 with add-on A1" -m "R-01 opening page: Subscribe Now to Account & Billing in the body, header and phone menu; navy Log in (AM-18, AM-22). R-02 Help: Go to the Top in the contents menu and, below 1024, at the end of the text; the menu scrolls inside itself when taller than the window (AM-19, AM-22). R-03 Login: Logging in… with aria-busy. R-04 disabled fields use the disabled tokens, no fade. R-05 Profile support link in the link style. R-06 44px password toggle, dashboard tabs and account button. R-07 no sideways overflow at 320 on the dashboard and Billing & subscription. Tests added for each. Reports and evidence are in the Portal repository, EVIDENCE/RWO01."
```

## Account & Billing (`STAGING_LIST_portal.txt`; optionally `STAGING_LIST_portal_optional.txt`)

```
git commit -m "fix(abm007-final): RWO-01 repairs R-04, R-08, R-09 with add-on A1; rulings AM-18 to AM-22 and evidence" -m "R-08 signed-out header: Sign in stays on one line at 768; footer links stack centered below 1024 on signed-out and signed-in pages (A1-4). R-09 44px password toggle and pharmacy-row buttons; Refresh ruled a link and left unchanged. R-04 shared input uses the disabled tokens, no fade. Tests added. Records: ABM_RULINGS AM-18 to AM-22, CHANGED_LABELS, EVIDENCE/RWO01 reports, measurements, logs and diffs; session log, RECOVERY block and ABM_STATE refresh of 26 Nov (AM-22 (3))."
```
