# RWO-01 changed files, grouped by item (whole of RWO-01, add-on A1 included)

Working-tree changes only. Nothing is staged or committed. Full diffs: `diff/owedbook_full.diff` and `diff/portal_full.diff`.

## OwedBook (`cyph-v1-dev`), 22 paths

| Item | Product file | Test |
|---|---|---|
| R-01 | `src/app/(public)/HomePageContent.tsx` | `src/__tests__/abm007/home-cta.test.tsx` (new) |
| R-02 | `src/components/help/HelpPage.tsx` | `src/__tests__/abm007/help-page.test.tsx` |
| R-03 | `src/components/auth/LoginForm.tsx` | `src/__tests__/auth/LoginForm.hydration.test.tsx` |
| R-04 | `src/components/ui/input.tsx` | `src/__tests__/member/ProfileForm.test.tsx` |
| R-05 | `src/app/profile/ProfileForm.tsx` | `src/__tests__/member/ProfileForm.test.tsx` (same file) |
| R-06 (a) | `src/components/ui/password-input.tsx` | `src/__tests__/auth/PasswordToggle.test.tsx` |
| R-06 (b) | `src/components/owedbook/OwedBookScreen.tsx` | `src/__tests__/owedbook/OwedBookScreen.test.tsx` |
| R-06 (c) | `src/components/global/Navbar.tsx`, `src/components/global/UserMenu.tsx` | `src/__tests__/global/Navbar.mobile.test.tsx`, `src/__tests__/global/UserMenu.test.tsx` |
| R-07 | `src/components/global/Navbar.tsx` (same file as R-06 (c)), `src/components/admin-portal/ScreenHeader.tsx` | `src/__tests__/global/Navbar.mobile.test.tsx` (same file). `ScreenHeader` has no existing test, so none was added |
| A1-1 | `src/components/global/UserMenu.tsx` (same file as R-06 (c)), `src/components/global/MobileNav.tsx` | `src/__tests__/global/UserMenu.test.tsx` (same file), `src/__tests__/global/MobileNav.test.tsx` |
| A1-2, A1-3 | `src/components/help/HelpPage.tsx` (same file as R-02) | `src/__tests__/abm007/help-page.test.tsx` (same file) |
| Records | `CHANGELOG.md`, `agent_docs/SESSIONS/session_2026-11-26.md` (new) | — |

Product files: 11. Test files: 9 (1 new, 8 extended). Record files: 2. The add-on added `MobileNav.tsx` and `MobileNav.test.tsx`; its other changes are in files RWO-01 had already changed.

## Account & Billing (`cyph-payment-portal-dev-v1`)

### RWO-01 items, 8 paths

| Item | Product file | Test |
|---|---|---|
| R-04 (same fade, same fix) | `src/components/ui/input.tsx` | No existing test covers this component; none added |
| R-08 | `src/components/portal/PublicShell.tsx`, `src/components/portal/Footer.tsx` | `src/__tests__/abm007/public-shell-fit.test.tsx` (new) |
| R-09 (a) | `src/components/portal/FormField.tsx` | `src/__tests__/password-field.test.tsx` |
| R-09 (b) | `src/components/portal/account/StoreRemovalControl.tsx` | `src/__tests__/manual-qa-portal-ui.test.tsx` |
| R-09 (c) | none (ruled a link; unchanged) | — |
| A1-4 | `src/components/portal/Footer.tsx` (same file as R-08) | `src/__tests__/abm007/public-shell-fit.test.tsx` (same file) |

Product files: 5. Test files: 3 (1 new, 2 extended). The add-on changed no further file here.

### RWO-01 records

| File | Change |
|---|---|
| `agent_docs/ACTIONS/ABM007_FINAL/ABM_RULINGS.md` | Rows AM-18 to AM-21 appended after AM-17, byte-identical to the release document; row AM-22 appended after AM-21, as given in the add-on |
| `agent_docs/ACTIONS/ABM007_FINAL/EVIDENCE/E2/CHANGED_LABELS.md` | RWO-01 section appended, then extended for the add-on |
| `agent_docs/ACTIONS/ABM007_FINAL/EVIDENCE/RWO01/` (new folder) | Both reports and their lists, `tools/measure.mjs` and `tools/measure_a1.mjs`, `measure/` data and masked screenshots, `logs/` and `logs_a1/`, `diff/`, `binding/` and `binding_a1/`, the staging lists and commit messages |
| `CHANGELOG.md`, `session_2026-11-26.md` | Appended entries |
| `agent_docs/RESPONSES/response_2026-11-26_*_rwo01-*.md`; the two return ZIP copies and their `.sha256` files in `EVIDENCE/RWO01/` | The return 02 response file and ZIP were written after the ZIP was built, so they are not inside it |

### Not RWO-01: record changes made earlier today at the Director's request (confirmed by ruling AM-22 (3))

| File | Change |
|---|---|
| `session_2026-11-26.md` (new) | Today's session log, started before RWO-01 arrived |
| `RECOVERY.md` | One block added at the top; nothing else changed |
| `agent_docs/ACTIONS/ABM007_FINAL/ABM_STATE.md` | Index refreshed to the QA state as it stood this morning |
| `CHANGELOG.md` | Two entries for the above |

### Not touched

`agent_docs/ACTIONS/ABM007_FINAL/QAM/` holds the QA Executor's uncommitted records. I changed nothing there, and both diffs leave it out.
