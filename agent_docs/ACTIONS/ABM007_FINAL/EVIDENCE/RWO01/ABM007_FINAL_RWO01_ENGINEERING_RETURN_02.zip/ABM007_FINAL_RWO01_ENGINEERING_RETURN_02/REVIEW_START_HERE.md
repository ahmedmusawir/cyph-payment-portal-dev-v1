# ABM007_FINAL RWO-01 engineering return 02 (add-on A1)

Status: `RWO-01 ADD-ON A1 COMPLETE — AWAITING DIRECTOR COMMIT`. Engineering claims for QA to test, not results.

Read in this order:
1. `RWO01_A1_ENGINEERING_REPORT.md`: the add-on, item by item, with before-and-after measurements, sessions and page loads.
2. `CHANGED_FILES.md`: every changed file for the whole of RWO-01, add-on included.
3. `diff/owedbook_full.diff` and `diff/portal_full.diff`: the full working-tree diffs against the candidate commits. `diff/addon_A1_only.diff` shows only what the add-on changed in product and test files. `diff/return01/` keeps return 01's diffs.
4. `logs_a1/`: unit tests, typecheck, lint and build for the add-on state. `logs/` keeps return 01's.
5. `measure/measure_a1_before.json`, `measure/measure_a1_after.json` and `measure/shots_*/A1-*`: the add-on measurements and masked screenshots. Return 01's are beside them.
6. `RWO01_ENGINEERING_REPORT.md`, `FREE_TRIAL_LIST.md`, `NOTICED_NOT_FIXED.md`: return 01's report and lists, the last two updated with the rulings.
7. `STAGING_LIST_*.txt` and `COMMIT_MESSAGES.md`: for the Director's commit.
8. `records/`: `ABM_RULINGS.md` (AM-18 to AM-22), `CHANGED_LABELS.md`, both session logs.

`FILE_INDEX.json` lists every member except itself, with size and SHA-256.
