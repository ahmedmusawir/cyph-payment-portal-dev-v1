# ABM007_FINAL RWO-01 engineering return 03 (add-on A2)

Status: `RWO-01 ADD-ON A2 COMPLETE — AWAITING QA CONFIRMATION`. Engineering claims for QA to test, not results.

Read in this order:
1. `RWO01_A2_ENGINEERING_REPORT.md`: add-on A2, item by item, with before-and-after measurements, the link's contrast at 375 and 1440, and sessions used.
2. `CHANGED_FILES.md`: every changed file for the whole of RWO-01, both add-ons included.
3. `diff/owedbook_full.diff` and `diff/portal_full.diff`: the full working-tree diffs against the candidate commits. `diff/addon_A2_only.diff` shows only what this add-on changed in product and test files. `diff/return02/` and `diff/return01/` keep the earlier returns' diffs.
4. `logs_a2/`: unit tests, typecheck, lint and build for this state. `logs_a1/` and `logs/` keep the earlier ones.
5. `measure/measure_a2_before.json`, `measure/measure_a2_after.json` and `measure/shots_a2_*/`: this add-on's measurements and masked screenshots. `measure_a2_before_run1.json` is a first run with a tool fault; the report, section 4, explains it.
6. `tools/measure_a2.mjs`: the measuring tool, with how an outline is judged written at its top.
7. `STAGING_LIST_*.txt` and `COMMIT_MESSAGES.md`: for the Director's commit, regenerated.
8. `NOTICED_NOT_FIXED.md`: section "Add-on A2" at the end.
9. `records/`: `ABM_RULINGS.md` (AM-18 to AM-23), `CHANGED_LABELS.md`, the session logs of 26 and 27 November for both repositories.
10. Earlier reports, unchanged: `RWO01_A1_ENGINEERING_REPORT.md`, `RWO01_ENGINEERING_REPORT.md`, `FREE_TRIAL_LIST.md`.

`FILE_INDEX.json` lists every member except itself, with size and SHA-256.
